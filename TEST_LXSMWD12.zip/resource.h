//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TEST_LXSMWD12.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TEST_LTYPE                  129
#define IDD_DLG_STATUSVIEW              130
#define IDC_BTN_OpenDevice              1000
#define IDC_LIST_STATUS1                1001
#define IDC_BUTTON1IDC_BTN_CloseDevice  1002
#define IDC_BTN_SetConfigMsg            1003
#define IDC_EDIT_HeartRate              1004
#define IDC_EDIT_Finger                 1005
#define IDC_EDIT_Stability              1006
#define IDC_EDIT_AutoSet                1007
#define IDC_EDIT_DiagStatus             1008
#define IDC_EDIT_DiagRTime              1009
#define IDC_EDIT_DiagResult             1010
#define IDC_PROGRESS_StreamQRemain      1011
#define IDC_EDIT_PerfusionIndex         1013
#define IDC_BTN_DiagStart               1017
#define IDC_EDIT_HBQty                  1019
#define IDC_EDIT_SNSBal                 1020
#define IDC_EDIT_PSNSBal                1021
#define IDC_EDIT_SNSAct                 1022
#define IDC_EDIT_SNSActLevel            1023
#define IDC_EDIT_PSNSAct                1024
#define IDC_EDIT_PSNSActLevel           1025
#define IDC_EDIT_ANSAct                 1026
#define IDC_EDIT_ANSActLevel            1027
#define IDC_EDIT_HRResult               1028
#define IDC_EDIT_HRResultLevel          1029
#define IDC_EDIT_PIResult               1030
#define IDC_EDIT_PIResultLevel          1031
#define IDC_EDIT_SNSBalLevel            1032
#define IDC_LIST_HISTORESULT            1034
#define IDC_LIST_HBIRESULT              1035
#define IDC_EDIT_LOWPI                  1036
#define IDC_EDIT_FaultHBI               1037
#define IDC_EDIT_AbnormalHBI            1038
#define IDC_EDIT_Active                 1039
#define IDC_EDIT_StressAcute            1040
#define IDC_EDIT_StressChronic          1041
#define IDC_EDIT1                       1042
#define ID_MENU_VIEWDLGSTATUS           32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
